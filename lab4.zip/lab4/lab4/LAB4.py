import numpy as np  # Importa la biblioteca NumPy para operaciones numéricas
import pandas as pd  # Importa la biblioteca Pandas para manipulación de datos
import scipy.signal as signal  # Importa la subbiblioteca de señales de SciPy para el procesamiento de señales
import pywt  # Importa PyWavelets para análisis de wavelets
import matplotlib.pyplot as plt  # Importa Matplotlib para la visualización de datos

# Parámetros de simulación
fs = 250  # Frecuencia de muestreo en Hz
duration_target = 5 * 60  # Duración objetivo en segundos (5 minutos)
samples_target = duration_target * fs  # Número de muestras objetivo

# Función para cargar y procesar el archivo CSV de ECG
def cargar_datos_ecg(filepath):
    try:
        # Carga el archivo CSV, omitiendo la primera fila y nombrando las columnas
        ecg_data = pd.read_csv(filepath, skiprows=1, names=['Elapsed_time', 'ECG'], quotechar="'")
        
        # Convierte las columnas a tipo numérico, ignorando errores
        ecg_data['Elapsed_time'] = pd.to_numeric(ecg_data['Elapsed_time'], errors='coerce')
        ecg_data['ECG'] = pd.to_numeric(ecg_data['ECG'], errors='coerce')
        
        # Elimina las filas con valores NaN
        ecg_data.dropna(inplace=True)
        
        # Extender la señal para que dure al menos 5 minutos
        ecg_signal = np.tile(ecg_data['ECG'].values, (samples_target // len(ecg_data) + 1))[:samples_target]
        
        # Crea un nuevo DataFrame con el tiempo y la señal ECG
        ecg_data = pd.DataFrame({'Elapsed_time': np.arange(len(ecg_signal)) / fs, 'ECG': ecg_signal})
        
        return ecg_data  # Devuelve el DataFrame procesado
    except Exception as e:
        print("Error al cargar el archivo de ECG:", e)  # Maneja excepciones
        return None  # Retorna None si hay un error

# Función para graficar la señal cruda
def graficar_senal_cruda(ecg_signal):
    tiempo = np.arange(len(ecg_signal)) / fs  # Calcula el tiempo correspondiente a cada muestra
    plt.figure(figsize=(12, 4))  # Crea una figura para la gráfica
    plt.plot(tiempo, ecg_signal, label='Señal ECG cruda')  # Grafica la señal ECG
    plt.title("Señal ECG cruda")  # Título de la gráfica
    plt.xlim(0, 30)  # Limita el eje x a 30 segundos
    plt.xlabel("Tiempo (s)")  # Etiqueta del eje x
    plt.ylabel("Amplitud")  # Etiqueta del eje y
    plt.legend()  # Muestra la leyenda
    plt.show()  # Muestra la gráfica

# Función de filtrado de señal con filtro notch
def filtrar_senal(ecg_signal, fs):
    # Crea un filtro pasabajo
    sos_low = signal.butter(4, 15, 'low', fs=fs, output='sos')
    ecg_filtered = signal.sosfilt(sos_low, ecg_signal)  # Aplica el filtro

    # Configuración del filtro notch para eliminar ruido a 55 Hz
    notch_freq = 55.0
    quality_factor = 30.0
    b_notch, a_notch = signal.iirnotch(notch_freq / (fs / 2), quality_factor)
    ecg_filtered = signal.filtfilt(b_notch, a_notch, ecg_filtered)  # Aplica el filtro notch

    # Crea un filtro pasaalto
    sos_high = signal.butter(4, 0.5, 'high', fs=fs, output='sos')
    ecg_filtered = signal.sosfilt(sos_high, ecg_filtered)  # Aplica el filtro

    return ecg_filtered  # Retorna la señal filtrada

# Función para detectar los picos R y calcular intervalos R-R
def detectar_picos_rr(ecg_filtered, fs):
    height = 0.5 * np.max(ecg_filtered)  # Define el umbral de altura para la detección de picos
    peaks, _ = signal.find_peaks(ecg_filtered, distance=int(0.6 * fs), height=height)  # Detecta los picos R
    rr_intervals = np.diff(peaks) / fs  # Calcula los intervalos R-R
    return peaks, rr_intervals  # Retorna los picos y los intervalos R-R

# Función para calcular parámetros de HRV
def calcular_hrv(rr_intervals):
    if len(rr_intervals) < 2:  # Asegura que haya suficientes intervalos R-R
        return None, None, None, None
    
    # Calcula los parámetros de HRV
    mean_rr = np.mean(rr_intervals)  # Media de intervalos R-R
    std_rr = np.std(rr_intervals)  # Desviación estándar de intervalos R-R
    rmssd = np.sqrt(np.mean(np.square(np.diff(rr_intervals))))  # RMSSD
    pnn50 = np.sum(np.abs(np.diff(rr_intervals)) > 0.05) / (len(rr_intervals) - 1) * 100  # pNN50
    
    return mean_rr, std_rr, rmssd, pnn50  # Retorna los parámetros calculados

# Función para aplicar la Transformada Wavelet Continua (CWT) con Morlet
def aplicar_wavelet(rr_intervals, fs):
    scales = np.arange(1, 128)  # Define las escalas para la transformada
    cwtmatr, freqs = pywt.cwt(rr_intervals, wavelet='cmor1.0-6.0', scales=scales, sampling_period=1/fs)  # Aplica CWT
    return cwtmatr, freqs  # Retorna la matriz CWT y las frecuencias

# Calcular características de la señal
def calcular_caracteristicas(ecg_data):
    frecuencia_muestreo = fs  # Almacena la frecuencia de muestreo
    tiempo_muestreo = 1 / frecuencia_muestreo  # Calcula el tiempo de muestreo
    niveles_cuantificacion = len(np.unique(ecg_data['ECG'].round(3)))  # Niveles de cuantificación

    # Calcula estadísticos principales de la señal
    estadisticos = {
        'Media': np.mean(ecg_data['ECG']),
        'Desviación estándar': np.std(ecg_data['ECG']),
        'Mínimo': np.min(ecg_data['ECG']),
        'Máximo': np.max(ecg_data['ECG']),
        'Mediana': np.median(ecg_data['ECG'])
    }

    return frecuencia_muestreo, tiempo_muestreo, niveles_cuantificacion, estadisticos  # Retorna las características

# Menú interactivo con opción para calcular características
def main_menu():
    print("---- Análisis de señal ECG y HRV ----")  # Título del menú
    print("1. Ver señal cruda ECG")  # Opción para ver señal cruda
    print("2. Filtrar señal ECG")  # Opción para filtrar señal
    print("3. Detectar picos R y calcular intervalos R-R")  # Opción para detectar picos
    print("4. Calcular parámetros de HRV en el dominio del tiempo")  # Opción para calcular HRV
    print("5. Aplicar Transformada Wavelet (Morlet)")  # Opción para aplicar wavelet
    print("6. Calcular características de la señal")  # Opción para calcular características
    print("7. Salir")  # Opción para salir
    return input("Seleccione una opción (1-7): ")  # Solicita al usuario una opción

def run_analysis():
    filepath = "deisiECG.csv"  # Ruta del archivo de ECG
    ecg_data = cargar_datos_ecg(filepath)  # Carga los datos ECG
    if ecg_data is None:  # Verifica si los datos se cargaron correctamente
        print("Error al cargar los datos. Asegúrese de que el archivo tenga el formato correcto.")
        return  # Sale si hay error

    ecg_signal = ecg_data['ECG'].values  # Obtiene la señal ECG
    ecg_filtered = None  # Inicializa la señal filtrada
    peaks = None  # Inicializa los picos
    rr_intervals = None  # Inicializa los intervalos R-R

    while True:  # Bucle principal para el menú
        option = main_menu()  # Muestra el menú y obtiene la opción
        
        if option == '1':
            graficar_senal_cruda(ecg_signal)  # Grafica la señal cruda
            print("Señal ECG cruda mostrada.")
        
        elif option == '2':
            ecg_filtered = filtrar_senal(ecg_signal, fs)  # Filtra la señal ECG
            plt.figure(figsize=(12, 4))
            plt.plot(ecg_filtered, label='ECG Filtrada')  # Grafica la señal filtrada
            plt.title("Señal ECG Filtrada")
            plt.xlabel("Muestras")
            plt.xlim(0, 5000)  # Limita el eje x a 5000 muestras
            plt.ylabel("Amplitud")
            plt.legend()
            plt.show()
            print("Señal ECG filtrada correctamente.")
        
        elif option == '3':
            if ecg_filtered is None:  # Verifica si la señal ha sido filtrada
                print("Primero debe filtrar la señal (opción 2).")
            else:
                peaks, rr_intervals = detectar_picos_rr(ecg_filtered, fs)  # Detecta picos R
                plt.figure(figsize=(12, 4))
                plt.plot(ecg_filtered, label='ECG Filtrada')  # Grafica la señal filtrada
                plt.plot(peaks, ecg_filtered[peaks], 'ro', label='Picos R')  # Marca los picos R
                plt.title("Detección de Picos R")
                plt.xlabel("Muestras")
                plt.xlim(0, 5000)  # Limita el eje x a 5000 muestras
                plt.ylabel("Amplitud")
                plt.legend()
                plt.show()
                print("Picos R detectados e intervalos R-R calculados.")
        
        elif option == '4':
            if rr_intervals is None:  # Verifica si los intervalos R-R han sido calculados
                print("Primero debe detectar los picos R y calcular intervalos R-R (opción 3).")
            else:
                # Calcula y muestra parámetros de HRV
                mean_rr, std_rr, rmssd, pnn50 = calcular_hrv(rr_intervals)
                print("Parámetros de HRV en el dominio del tiempo:")
                print(f"Media de intervalos R-R: {mean_rr:.3f} s")
                print(f"Desviación estándar de intervalos R-R: {std_rr:.3f} s")
                print(f"RMSSD: {rmssd:.3f} s")
                print(f"pNN50: {pnn50:.2f}%")
        
        elif option == '5':
            if rr_intervals is None:  # Verifica si los intervalos R-R han sido calculados
                print("Primero debe detectar los picos R y calcular intervalos R-R (opción 3).")
            else:
                cwtmatr, freqs = aplicar_wavelet(rr_intervals, fs)  # Aplica la Transformada Wavelet
                plt.figure(figsize=(10, 6))
                plt.imshow(np.abs(cwtmatr), extent=[0, len(rr_intervals), freqs[-1], freqs[0]], aspect='auto', cmap='jet')  # Muestra el espectrograma
                plt.colorbar(label="Potencia")  # Añade barra de color
                plt.title("Espectrograma Wavelet de la HRV (Morlet)")
                plt.xlabel("Tiempo")
                plt.ylabel("Frecuencia (Hz)")
                plt.show()
                print("Transformada Wavelet aplicada y espectrograma mostrado.")
        
        elif option == '6':
            # Calcula y muestra características de la señal ECG
            frecuencia_muestreo, tiempo_muestreo, niveles_cuantificacion, estadisticos = calcular_caracteristicas(ecg_data)
            print("Características de la señal ECG:")
            print(f"Frecuencia de muestreo: {frecuencia_muestreo} Hz")
            print(f"Tiempo de muestreo: {tiempo_muestreo:.6f} s")
            print(f"Niveles de cuantificación: {niveles_cuantificacion}")
            print("Estadísticos principales de la señal:")
            for key, value in estadisticos.items():
                print(f"{key}: {value:.3f}")
        
        elif option == '7':
            print("Saliendo del programa.")  # Mensaje de salida
            break  # Sale del bucle y finaliza el programa
        
        else:
            print("Opción no válida. Intente de nuevo.")  # Mensaje de error si la opción es inválida

# Ejecutar el menú
run_analysis()  # Inicia el análisis
